public class Product {
    String name;

    public Product(String name) {
        this.name = name;
    }
}
